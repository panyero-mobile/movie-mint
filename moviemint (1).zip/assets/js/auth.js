// Import the Firebase SDKs
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js"
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  onAuthStateChanged,
  GoogleAuthProvider,
  signInWithPopup,
} from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js"
import { getDatabase, ref, set } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-database.js"
import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-analytics.js"

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBe9a58zaQCrBSGeWwcIVa_PnZABoH6zV4",
  authDomain: "tudds-ccd0wn.firebaseapp.com",
  databaseURL: "https://tudds-ccd0wn-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "tudds-ccd0wn",
  storageBucket: "tudds-ccd0wn.appspot.com",
  messagingSenderId: "786974954352",
  appId: "1:786974954352:web:29d08d6ef6c1c6239bb5b5",
  measurementId: "G-11731SMXHJ",
}

// Initialize Firebase
let app
let auth
let database
let analytics

function initAuth() {
  try {
    app = initializeApp(firebaseConfig)
    auth = getAuth(app)
    database = getDatabase(app)
    analytics = getAnalytics(app)
  } catch (e) {
    console.error("Firebase initialization error:", e)
    return
  }

  // Check current page
  const currentPage = window.location.pathname

  // Handle sign up
  if (currentPage.includes("signup.html")) {
    setupSignUp()
  }

  // Handle sign in
  else if (currentPage.includes("signin.html")) {
    setupSignIn()
  }

  // Handle reset password
  else if (currentPage.includes("resetpassword.html")) {
    setupResetPassword()
  }

  // Handle profile page
  else if (currentPage.includes("profile.html")) {
    setupProfilePage()
  }

  // Check auth state for all pages
  onAuthStateChanged(auth, (user) => {
    if (user) {
      // User is signed in
      updateUIForSignedInUser(user)
    } else {
      // User is signed out
      updateUIForSignedOutUser()
    }

    // Check if redirection is needed
    checkAuthAndRedirect()
  })
}

// Check if user is authenticated and redirect if needed
function checkAuthAndRedirect() {
  const currentUser = auth.currentUser
  const currentPage = window.location.pathname

  // Pages that don't require authentication
  const publicPages = ["/signup.html", "/signin.html", "/resetpassword.html"]

  // Check if current page is a public page
  const isPublicPage = publicPages.some((page) => currentPage.includes(page))

  // If user is not authenticated and not on a public page, redirect to signup
  if (!currentUser && !isPublicPage && !currentPage.includes("/index.html")) {
    window.location.href = "./signup.html"
    return
  }
}

// Set up sign up functionality
function setupSignUp() {
  const signupForm = document.getElementById("signup-form")
  const googleSignupBtn = document.getElementById("google-signup")

  if (signupForm) {
    signupForm.addEventListener("submit", (e) => {
      e.preventDefault()

      // Get form values
      const name = document.getElementById("name").value
      const email = document.getElementById("email").value
      const password = document.getElementById("password").value
      const confirmPassword = document.getElementById("confirm-password").value

      // Reset errors
      resetFormErrors()

      // Validate form
      if (!name) {
        showError("name-error", "Please enter your name")
        return
      }

      if (!email) {
        showError("email-error", "Please enter your email")
        return
      }

      if (!password) {
        showError("password-error", "Please enter a password")
        return
      }

      if (password.length < 6) {
        showError("password-error", "Password must be at least 6 characters")
        return
      }

      if (password !== confirmPassword) {
        showError("confirm-password-error", "Passwords do not match")
        return
      }

      // Disable button
      const signupBtn = document.getElementById("signup-btn")
      signupBtn.disabled = true
      signupBtn.textContent = "Creating Account..."

      // Create user with email and password
      createUserWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
          // Update profile
          return userCredential.user.updateProfile({
            displayName: name,
          })
        })
        .then(() => {
          // Save user data to database
          const user = auth.currentUser
          return set(ref(database, "users/" + user.uid), {
            name: name,
            email: email,
            createdAt: new Date().toISOString(),
          })
        })
        .then(() => {
          // Redirect to home page
          window.location.href = "./index.html"
        })
        .catch((error) => {
          // Handle errors
          if (error.code === "auth/email-already-in-use") {
            showError("email-error", "Email already in use")
          } else if (error.code === "auth/invalid-email") {
            showError("email-error", "Invalid email address")
          } else if (error.code === "auth/weak-password") {
            showError("password-error", "Password is too weak")
          } else {
            showError("email-error", error.message)
          }

          // Re-enable button
          signupBtn.disabled = false
          signupBtn.textContent = "Create Account"
        })
    })
  }

  // Google sign up
  if (googleSignupBtn) {
    googleSignupBtn.addEventListener("click", () => {
      const provider = new GoogleAuthProvider()

      signInWithPopup(auth, provider)
        .then((result) => {
          // Check if user is new
          const isNewUser = result.additionalUserInfo.isNewUser

          if (isNewUser) {
            // Save user data to database
            const user = result.user
            return set(ref(database, "users/" + user.uid), {
              name: user.displayName,
              email: user.email,
              createdAt: new Date().toISOString(),
            })
          }
        })
        .then(() => {
          // Redirect to home page
          window.location.href = "./index.html"
        })
        .catch((error) => {
          console.error("Google sign up error:", error)
          alert("Google sign up failed: " + error.message)
        })
    })
  }
}

// Set up sign in functionality
function setupSignIn() {
  const signinForm = document.getElementById("signin-form")
  const googleSigninBtn = document.getElementById("google-signin")

  if (signinForm) {
    signinForm.addEventListener("submit", (e) => {
      e.preventDefault()

      // Get form values
      const email = document.getElementById("email").value
      const password = document.getElementById("password").value

      // Reset errors
      resetFormErrors()

      // Validate form
      if (!email) {
        showError("email-error", "Please enter your email")
        return
      }

      if (!password) {
        showError("password-error", "Please enter your password")
        return
      }

      // Disable button
      const signinBtn = document.getElementById("signin-btn")
      signinBtn.disabled = true
      signinBtn.textContent = "Signing In..."

      // Sign in with email and password
      signInWithEmailAndPassword(auth, email, password)
        .then(() => {
          // Redirect to home page
          window.location.href = "./index.html"
        })
        .catch((error) => {
          // Handle errors
          if (error.code === "auth/user-not-found" || error.code === "auth/wrong-password") {
            showError("email-error", "Invalid email or password")
          } else if (error.code === "auth/invalid-email") {
            showError("email-error", "Invalid email address")
          } else if (error.code === "auth/user-disabled") {
            showError("email-error", "Your account has been disabled")
          } else {
            showError("email-error", error.message)
          }

          // Re-enable button
          signinBtn.disabled = false
          signinBtn.textContent = "Sign In"
        })
    })
  }

  // Google sign in
  if (googleSigninBtn) {
    googleSigninBtn.addEventListener("click", () => {
      const provider = new GoogleAuthProvider()

      signInWithPopup(auth, provider)
        .then((result) => {
          // Check if user is new
          const isNewUser = result.additionalUserInfo.isNewUser

          if (isNewUser) {
            // Save user data to database
            const user = result.user
            return set(ref(database, "users/" + user.uid), {
              name: user.displayName,
              email: user.email,
              createdAt: new Date().toISOString(),
            })
          }
        })
        .then(() => {
          // Redirect to home page
          window.location.href = "./index.html"
        })
        .catch((error) => {
          console.error("Google sign in error:", error)
          alert("Google sign in failed: " + error.message)
        })
    })
  }
}

// Set up reset password functionality
function setupResetPassword() {
  const resetForm = document.getElementById("reset-form")
  const backToSigninBtn = document.getElementById("back-to-signin")

  if (resetForm) {
    resetForm.addEventListener("submit", (e) => {
      e.preventDefault()

      // Get form values
      const email = document.getElementById("email").value

      // Reset errors
      resetFormErrors()

      // Validate form
      if (!email) {
        showError("email-error", "Please enter your email")
        return
      }

      // Disable button
      const resetBtn = document.getElementById("reset-btn")
      resetBtn.disabled = true
      resetBtn.textContent = "Sending..."

      // Send password reset email
      sendPasswordResetEmail(auth, email)
        .then(() => {
          // Show success message
          document.getElementById("reset-form-container").style.display = "none"
          document.getElementById("reset-success").style.display = "block"
        })
        .catch((error) => {
          // Handle errors
          if (error.code === "auth/user-not-found") {
            showError("email-error", "No account found with this email")
          } else if (error.code === "auth/invalid-email") {
            showError("email-error", "Invalid email address")
          } else {
            showError("email-error", error.message)
          }

          // Re-enable button
          resetBtn.disabled = false
          resetBtn.textContent = "Send Reset Link"
        })
    })
  }

  if (backToSigninBtn) {
    backToSigninBtn.addEventListener("click", () => {
      window.location.href = "./signin.html"
    })
  }
}

// Set up profile page
function setupProfilePage() {
  const signOutBtn = document.getElementById("sign-out-btn")
  const signInBtn = document.getElementById("sign-in-btn")
  const signUpBtn = document.getElementById("sign-up-btn")

  if (signOutBtn) {
    signOutBtn.addEventListener("click", () => {
      signOut(auth)
        .then(() => {
          // Redirect to home page
          window.location.href = "./index.html"
        })
        .catch((error) => {
          console.error("Sign out error:", error)
          alert("Sign out failed: " + error.message)
        })
    })
  }

  if (signInBtn) {
    signInBtn.addEventListener("click", () => {
      window.location.href = "./signin.html"
    })
  }

  if (signUpBtn) {
    signUpBtn.addEventListener("click", () => {
      window.location.href = "./signup.html"
    })
  }
}

// Update UI for signed in user
function updateUIForSignedInUser(user) {
  // Update profile page if it exists
  const signedInContent = document.getElementById("signed-in-content")
  const signedOutContent = document.getElementById("signed-out-content")

  if (signedInContent && signedOutContent) {
    signedInContent.style.display = "block"
    signedOutContent.style.display = "none"
  }

  // Update profile info
  const profileName = document.getElementById("profile-name")
  const profileEmail = document.getElementById("profile-email")
  const profileInitial = document.getElementById("profile-initial")
  const profileAvatarInitial = document.getElementById("profile-avatar-initial")

  if (profileName) {
    profileName.textContent = user.displayName || "User"
  }

  if (profileEmail) {
    profileEmail.textContent = user.email
  }

  if (profileInitial) {
    const initial = user.displayName ? user.displayName.charAt(0).toUpperCase() : "U"
    profileInitial.textContent = initial
  }

  if (profileAvatarInitial) {
    const initial = user.displayName ? user.displayName.charAt(0).toUpperCase() : "U"
    profileAvatarInitial.textContent = initial
  }
}

// Update UI for signed out user
function updateUIForSignedOutUser() {
  // Update profile page if it exists
  const signedInContent = document.getElementById("signed-in-content")
  const signedOutContent = document.getElementById("signed-out-content")

  if (signedInContent && signedOutContent) {
    signedInContent.style.display = "none"
    signedOutContent.style.display = "block"
  }

  // Update profile info
  const profileName = document.getElementById("profile-name")
  const profileEmail = document.getElementById("profile-email")
  const profileInitial = document.getElementById("profile-initial")
  const profileAvatarInitial = document.getElementById("profile-avatar-initial")

  if (profileName) {
    profileName.textContent = "Guest User"
  }

  if (profileEmail) {
    profileEmail.textContent = "Not signed in"
  }

  if (profileInitial) {
    profileInitial.textContent = "?"
  }

  if (profileAvatarInitial) {
    profileAvatarInitial.textContent = "?"
  }
}

// Helper function to show form errors
function showError(elementId, message) {
  const errorElement = document.getElementById(elementId)
  if (errorElement) {
    errorElement.textContent = message
    errorElement.classList.add("visible")
  }
}

// Helper function to reset form errors
function resetFormErrors() {
  const errorElements = document.querySelectorAll(".form-error")
  errorElements.forEach((element) => {
    element.textContent = ""
    element.classList.remove("visible")
  })
}

// Initialize auth when the DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  initAuth()
})

