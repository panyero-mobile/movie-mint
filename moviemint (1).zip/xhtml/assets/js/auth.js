// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBxYI_-UWP-V_5hAO9VVzlWvJRBkEFAVJI",
  authDomain: "moviemint-app.firebaseapp.com",
  projectId: "moviemint-app",
  storageBucket: "moviemint-app.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:1234567890abcdef",
}

// Initialize Firebase if it hasn't been initialized yet
if (typeof firebase === "undefined" || !firebase.apps.length) {
  // Declare firebase variable
  let firebase

  // Load Firebase scripts dynamically
  const loadFirebase = () => {
    return new Promise((resolve, reject) => {
      // Load Firebase core
      const firebaseCore = document.createElement("script")
      firebaseCore.src = "https://www.gstatic.com/firebasejs/8.10.1/firebase-app.js"
      firebaseCore.onload = () => {
        // Load Firebase auth
        const firebaseAuth = document.createElement("script")
        firebaseAuth.src = "https://www.gstatic.com/firebasejs/8.10.1/firebase-auth.js"
        firebaseAuth.onload = () => {
          // Initialize Firebase
          firebase = firebaseCore.contentWindow.firebase
          firebase.initializeApp(firebaseConfig)
          resolve()
        }
        firebaseAuth.onerror = reject
        document.head.appendChild(firebaseAuth)
      }
      firebaseCore.onerror = reject
      document.head.appendChild(firebaseCore)
    })
  }

  // Load Firebase and then initialize auth
  loadFirebase()
    .then(() => {
      initAuth()
    })
    .catch((error) => {
      console.error("Error loading Firebase:", error)
    })
} else {
  // Firebase is already loaded, just initialize auth
  initAuth()
}

// Initialize authentication functionality
function initAuth() {
  // Check if we're on the signup page
  const isSignupPage = window.location.pathname.includes("signup.html")
  const isSigninPage = window.location.pathname.includes("signin.html")
  const isResetPasswordPage = window.location.pathname.includes("resetpassword.html")
  const isIndexPage =
    window.location.pathname.includes("index.html") ||
    window.location.pathname === "/" ||
    window.location.pathname === ""

  // Set up auth state change listener
  firebase.auth().onAuthStateChanged((user) => {
    if (user) {
      // User is signed in
      console.log("User is signed in:", user.email)

      // If on auth pages, redirect to home
      if (isSignupPage || isSigninPage || isResetPasswordPage) {
        window.location.href = "./index.html"
      }
    } else {
      // User is not signed in
      console.log("User is not signed in")

      // If not on auth pages or index page, redirect to signup
      if (!isSignupPage && !isSigninPage && !isResetPasswordPage && !isIndexPage) {
        window.location.href = "./signup.html"
      }
    }
  })

  // Set up signup form if it exists
  const signupForm = document.getElementById("signup-form")
  if (signupForm) {
    signupForm.addEventListener("submit", (e) => {
      e.preventDefault()

      const email = document.getElementById("email").value
      const password = document.getElementById("password").value
      const confirmPassword = document.getElementById("confirm-password").value

      // Validate passwords match
      if (password !== confirmPassword) {
        showError("Passwords do not match")
        return
      }

      // Show loading state
      const submitButton = signupForm.querySelector('button[type="submit"]')
      const originalButtonText = submitButton.textContent
      submitButton.disabled = true
      submitButton.textContent = "Creating account..."

      // Create user with email and password
      firebase
        .auth()
        .createUserWithEmailAndPassword(email, password)
        .then((userCredential) => {
          // Signed in
          const user = userCredential.user
          console.log("User created:", user.email)

          // Redirect to home page
          window.location.href = "./index.html"
        })
        .catch((error) => {
          // Handle errors
          console.error("Signup error:", error)
          showError(error.message)

          // Reset button
          submitButton.disabled = false
          submitButton.textContent = originalButtonText
        })
    })
  }

  // Set up signin form if it exists
  const signinForm = document.getElementById("signin-form")
  if (signinForm) {
    signinForm.addEventListener("submit", (e) => {
      e.preventDefault()

      const email = document.getElementById("email").value
      const password = document.getElementById("password").value

      // Show loading state
      const submitButton = signinForm.querySelector('button[type="submit"]')
      const originalButtonText = submitButton.textContent
      submitButton.disabled = true
      submitButton.textContent = "Signing in..."

      // Sign in with email and password
      firebase
        .auth()
        .signInWithEmailAndPassword(email, password)
        .then((userCredential) => {
          // Signed in
          const user = userCredential.user
          console.log("User signed in:", user.email)

          // Redirect to home page
          window.location.href = "./index.html"
        })
        .catch((error) => {
          // Handle errors
          console.error("Signin error:", error)
          showError(error.message)

          // Reset button
          submitButton.disabled = false
          submitButton.textContent = originalButtonText
        })
    })
  }

  // Set up reset password form if it exists
  const resetPasswordForm = document.getElementById("reset-password-form")
  if (resetPasswordForm) {
    resetPasswordForm.addEventListener("submit", (e) => {
      e.preventDefault()

      const email = document.getElementById("email").value

      // Show loading state
      const submitButton = resetPasswordForm.querySelector('button[type="submit"]')
      const originalButtonText = submitButton.textContent
      submitButton.disabled = true
      submitButton.textContent = "Sending email..."

      // Send password reset email
      firebase
        .auth()
        .sendPasswordResetEmail(email)
        .then(() => {
          // Email sent
          console.log("Password reset email sent to:", email)
          showSuccess("Password reset email sent. Check your inbox.")

          // Reset button
          submitButton.disabled = false
          submitButton.textContent = originalButtonText
        })
        .catch((error) => {
          // Handle errors
          console.error("Reset password error:", error)
          showError(error.message)

          // Reset button
          submitButton.disabled = false
          submitButton.textContent = originalButtonText
        })
    })
  }

  // Set up signout button if it exists
  const signoutButton = document.getElementById("signout-button")
  if (signoutButton) {
    signoutButton.addEventListener("click", (e) => {
      e.preventDefault()

      firebase
        .auth()
        .signOut()
        .then(() => {
          // Sign-out successful
          console.log("User signed out")

          // Redirect to signin page
          window.location.href = "./signin.html"
        })
        .catch((error) => {
          // An error happened
          console.error("Signout error:", error)
        })
    })
  }

  // Helper function to show error messages
  function showError(message) {
    const errorElement = document.querySelector(".auth-error")
    if (errorElement) {
      errorElement.textContent = message
      errorElement.style.display = "block"
    } else {
      alert(message)
    }
  }

  // Helper function to show success messages
  function showSuccess(message) {
    const successElement = document.querySelector(".auth-success")
    if (successElement) {
      successElement.textContent = message
      successElement.style.display = "block"
    } else {
      alert(message)
    }
  }
}

// Function to check authentication and redirect if necessary
function checkAuthAndRedirect() {
  // Public pages that don't require authentication
  const publicPages = ["/signup.html", "/signin.html", "/resetpassword.html", "/index.html"]

  // Get current page path
  const currentPath = window.location.pathname

  // Check if current page is a public page
  const isPublicPage = publicPages.some(
    (page) => currentPath.includes(page) || currentPath === "/" || currentPath === "",
  )

  // If Firebase is loaded, check auth state
  if (typeof firebase !== "undefined" && firebase.auth) {
    firebase.auth().onAuthStateChanged((user) => {
      if (!user && !isPublicPage) {
        // User is not signed in and not on a public page, redirect to signup
        window.location.href = "./signup.html"
      }
    })
  }
}

// Export functions for global use
window.initAuth = initAuth
window.checkAuthAndRedirect = checkAuthAndRedirect

// Call checkAuthAndRedirect when the script loads
checkAuthAndRedirect()

