// This script is for reference only - it shows how to create the PWA icons
// You would run this once to generate the icons, not include it in the app

const fs = require("fs")
const path = require("path")
const { createCanvas } = require("canvas")

// Create directory if it doesn't exist
const iconsDir = path.join(__dirname, "../images/icons")
if (!fs.existsSync(iconsDir)) {
  fs.mkdirSync(iconsDir, { recursive: true })
}

// Icon sizes
const sizes = [72, 96, 128, 144, 152, 192, 384, 512]

// Create icons
sizes.forEach((size) => {
  const canvas = createCanvas(size, size)
  const ctx = canvas.getContext("2d")

  // Background
  ctx.fillStyle = "#000000"
  ctx.fillRect(0, 0, size, size)

  // Logo text
  ctx.fillStyle = "#E50914"
  ctx.font = `bold ${size * 0.3}px Arial`
  ctx.textAlign = "center"
  ctx.textBaseline = "middle"
  ctx.fillText("PANYERO", size / 2, size / 2)

  // Save to file
  const buffer = canvas.toBuffer("image/png")
  fs.writeFileSync(path.join(iconsDir, `icon-${size}x${size}.png`), buffer)

  console.log(`Created icon-${size}x${size}.png`)
})

// Create favicon
const faviconCanvas = createCanvas(32, 32)
const faviconCtx = faviconCanvas.getContext("2d")

faviconCtx.fillStyle = "#000000"
faviconCtx.fillRect(0, 0, 32, 32)

faviconCtx.fillStyle = "#E50914"
faviconCtx.font = "bold 10px Arial"
faviconCtx.textAlign = "center"
faviconCtx.textBaseline = "middle"
faviconCtx.fillText("P", 16, 16)

const faviconBuffer = faviconCanvas.toBuffer("image/png")
fs.writeFileSync(path.join(iconsDir, "favicon.ico"), faviconBuffer)

console.log("Created favicon.ico")

