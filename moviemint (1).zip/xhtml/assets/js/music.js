// Music Player Implementation
import { search } from "./search.js"

// Audio tracks data - these are free-to-use tracks with direct URLs
const audioTracks = [
  {
    id: 1,
    title: "Summer Walk",
    artist: "Olexy",
    duration: 180, // in seconds
    cover:
      "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
    url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/no_curator/Tours/Enthusiast/Tours_-_01_-_Enthusiast.mp3",
  },
  {
    id: 2,
    title: "Acoustic Breeze",
    artist: "Benjamin Tissot",
    duration: 146,
    cover:
      "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
    url: "https://www.bensound.com/bensound-music/bensound-acousticbreeze.mp3",
  },
  {
    id: 3,
    title: "A New Beginning",
    artist: "Alex",
    duration: 124,
    cover:
      "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
    url: "https://www.bensound.com/bensound-music/bensound-anewbeginning.mp3",
  },
  {
    id: 4,
    title: "Creative Minds",
    artist: "Benjamin Tissot",
    duration: 174,
    cover:
      "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
    url: "https://www.bensound.com/bensound-music/bensound-creativeminds.mp3",
  },
  {
    id: 5,
    title: "Going Higher",
    artist: "Benjamin Tissot",
    duration: 242,
    cover:
      "https://images.unsplash.com/photo-1487180144351-b8472da7d491?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
    url: "https://www.bensound.com/bensound-music/bensound-goinghigher.mp3",
  },
  {
    id: 6,
    title: "Memories",
    artist: "Benjamin Tissot",
    duration: 230,
    cover:
      "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
    url: "https://www.bensound.com/bensound-music/bensound-memories.mp3",
  },
  {
    id: 7,
    title: "Once Again",
    artist: "Benjamin Tissot",
    duration: 260,
    cover:
      "https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
    url: "https://www.bensound.com/bensound-music/bensound-onceagain.mp3",
  },
  {
    id: 8,
    title: "Sunny",
    artist: "Benjamin Tissot",
    duration: 140,
    cover:
      "https://images.unsplash.com/photo-1415201364774-f6f0bb35f28f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
    url: "https://www.bensound.com/bensound-music/bensound-sunny.mp3",
  },
]

// Music categories data
const musicCategories = [
  {
    name: "Pop",
    image:
      "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    name: "Rock",
    image:
      "https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    name: "Hip Hop",
    image:
      "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    name: "Electronic",
    image:
      "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    name: "Jazz",
    image:
      "https://images.unsplash.com/photo-1415201364774-f6f0bb35f28f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    name: "Classical",
    image:
      "https://images.unsplash.com/photo-1507838153414-b4b713384a76?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    name: "R&B",
    image:
      "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    name: "Country",
    image:
      "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
]

// Popular albums data
const popularAlbums = [
  {
    title: "Renaissance",
    artist: "Beyoncé",
    cover:
      "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    title: "Midnights",
    artist: "Taylor Swift",
    cover:
      "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    title: "Un Verano Sin Ti",
    artist: "Bad Bunny",
    cover:
      "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    title: "Harry's House",
    artist: "Harry Styles",
    cover:
      "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    title: "SOS",
    artist: "SZA",
    cover:
      "https://images.unsplash.com/photo-1487180144351-b8472da7d491?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    title: "Honestly, Nevermind",
    artist: "Drake",
    cover:
      "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
]

// New releases data
const newReleases = [
  {
    title: "Endless Summer Vacation",
    artist: "Miley Cyrus",
    cover:
      "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    title: "Beg For You",
    artist: "Charli XCX",
    cover:
      "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    title: "Trustfall",
    artist: "P!nk",
    cover:
      "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    title: "Mañana Será Bonito",
    artist: "Karol G",
    cover:
      "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    title: "Subtract",
    artist: "Ed Sheeran",
    cover:
      "https://images.unsplash.com/photo-1487180144351-b8472da7d491?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    title: "Guts",
    artist: "Olivia Rodrigo",
    cover:
      "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
]

// Trending artists data
const trendingArtists = [
  {
    name: "Taylor Swift",
    image:
      "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    name: "The Weeknd",
    image:
      "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    name: "Bad Bunny",
    image:
      "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    name: "Beyoncé",
    image:
      "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    name: "Drake",
    image:
      "https://images.unsplash.com/photo-1487180144351-b8472da7d491?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    name: "Dua Lipa",
    image:
      "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    name: "Harry Styles",
    image:
      "https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
  {
    name: "Billie Eilish",
    image:
      "https://images.unsplash.com/photo-1415201364774-f6f0bb35f28f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
  },
]

// Initialize the music player
document.addEventListener("DOMContentLoaded", () => {
  // DOM elements
  const audioPlayer = document.getElementById("audio-player")
  const playPauseBtn = document.getElementById("play-pause")
  const playIcon = document.getElementById("play-icon")
  const pauseIcon = document.getElementById("pause-icon")
  const prevBtn = document.getElementById("prev-track")
  const nextBtn = document.getElementById("next-track")
  const progressBar = document.getElementById("progress-bar")
  const progressContainer = document.querySelector(".progress-bar")
  const currentTimeEl = document.getElementById("current-time")
  const totalTimeEl = document.getElementById("total-time")
  const featuredTracksContainer = document.getElementById("featured-tracks")
  const musicCategoriesContainer = document.getElementById("music-categories")
  const popularAlbumsContainer = document.getElementById("popular-albums")
  const newReleasesContainer = document.getElementById("new-releases")
  const trendingArtistsContainer = document.getElementById("trending-artists")
  const miniPlayer = document.getElementById("mini-player")
  const miniPlayPauseBtn = document.getElementById("mini-play-pause")
  const miniPlayIcon = document.getElementById("mini-play-icon")
  const miniPauseIcon = document.getElementById("mini-pause-icon")
  const miniPrevBtn = document.getElementById("mini-prev")
  const miniNextBtn = document.getElementById("mini-next")
  const miniPlayerTitle = document.getElementById("mini-player-title")
  const miniPlayerArtist = document.getElementById("mini-player-artist")
  const miniPlayerImage = document.getElementById("mini-player-image")
  const musicSearchInput = document.getElementById("music-search-input")
  const musicSearchResults = document.getElementById("music-search-results")

  // Player state
  let currentTrackIndex = 0
  let isPlaying = false

  // Format time in MM:SS
  function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = Math.floor(seconds % 60)
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  // Load track
  function loadTrack(index) {
    if (index < 0) index = audioTracks.length - 1
    if (index >= audioTracks.length) index = 0

    currentTrackIndex = index
    const track = audioTracks[currentTrackIndex]

    audioPlayer.src = track.url
    audioPlayer.load()

    // Update mini player
    miniPlayerTitle.textContent = track.title
    miniPlayerArtist.textContent = track.artist
    miniPlayerImage.src = track.cover

    // Show mini player
    miniPlayer.classList.add("active")

    // Update total time
    totalTimeEl.textContent = formatTime(track.duration)

    // Update playlist items
    document.querySelectorAll(".playlist-item").forEach((item, i) => {
      if (i === currentTrackIndex) {
        item.classList.add("active")
      } else {
        item.classList.remove("active")
      }
    })

    // Auto play if was playing
    if (isPlaying) {
      playTrack()
    }
  }

  // Play track
  function playTrack() {
    audioPlayer.play()
    isPlaying = true
    playIcon.style.display = "none"
    pauseIcon.style.display = "block"
    miniPlayIcon.style.display = "none"
    miniPauseIcon.style.display = "block"
  }

  // Pause track
  function pauseTrack() {
    audioPlayer.pause()
    isPlaying = false
    playIcon.style.display = "block"
    pauseIcon.style.display = "none"
    miniPlayIcon.style.display = "block"
    miniPauseIcon.style.display = "none"
  }

  // Previous track
  function prevTrack() {
    loadTrack(currentTrackIndex - 1)
    if (isPlaying) playTrack()
  }

  // Next track
  function nextTrack() {
    loadTrack(currentTrackIndex + 1)
    if (isPlaying) playTrack()
  }

  // Update progress bar
  function updateProgress() {
    const { currentTime, duration } = audioPlayer
    const progressPercent = (currentTime / duration) * 100
    progressBar.style.width = `${progressPercent}%`
    currentTimeEl.textContent = formatTime(currentTime)
  }

  // Set progress bar
  function setProgress(e) {
    const width = this.clientWidth
    const clickX = e.offsetX
    const duration = audioPlayer.duration
    audioPlayer.currentTime = (clickX / width) * duration
  }

  // Event listeners
  playPauseBtn.addEventListener("click", () => {
    if (isPlaying) {
      pauseTrack()
    } else {
      playTrack()
    }
  })

  miniPlayPauseBtn.addEventListener("click", () => {
    if (isPlaying) {
      pauseTrack()
    } else {
      playTrack()
    }
  })

  prevBtn.addEventListener("click", prevTrack)
  nextBtn.addEventListener("click", nextTrack)
  miniPrevBtn.addEventListener("click", prevTrack)
  miniNextBtn.addEventListener("click", nextTrack)

  audioPlayer.addEventListener("timeupdate", updateProgress)
  progressContainer.addEventListener("click", setProgress)

  audioPlayer.addEventListener("ended", nextTrack)

  // Load music categories
  function loadMusicCategories() {
    musicCategoriesContainer.innerHTML = ""

    musicCategories.forEach((category) => {
      const categoryEl = document.createElement("div")
      categoryEl.classList.add("music-category")
      categoryEl.innerHTML = `
        <div class="music-category-image">
          <img src="${category.image}" alt="${category.name}" class="img-cover">
        </div>
        <div class="music-category-title">${category.name}</div>
      `

      categoryEl.addEventListener("click", () => {
        alert(`${category.name} category selected. This would filter music by ${category.name}.`)
      })

      musicCategoriesContainer.appendChild(categoryEl)
    })
  }

  // Load featured tracks
  function loadFeaturedTracks() {
    featuredTracksContainer.innerHTML = ""

    audioTracks.forEach((track, index) => {
      const trackEl = document.createElement("div")
      trackEl.classList.add("playlist-item")
      if (index === currentTrackIndex) trackEl.classList.add("active")

      trackEl.innerHTML = `
        <div class="playlist-item-play-icon">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
            <path d="M8 5v14l11-7z"/>
          </svg>
        </div>
        <div class="playlist-item-number">${index + 1}</div>
        <div class="playlist-item-info">
          <div class="playlist-item-title">${track.title}</div>
          <div class="playlist-item-artist">${track.artist}</div>
        </div>
        <div class="playlist-item-duration">${formatTime(track.duration)}</div>
      `

      trackEl.addEventListener("click", () => {
        currentTrackIndex = index
        loadTrack(currentTrackIndex)
        playTrack()
      })

      featuredTracksContainer.appendChild(trackEl)
    })
  }

  // Load popular albums
  function loadPopularAlbums() {
    popularAlbumsContainer.innerHTML = ""

    popularAlbums.forEach((album) => {
      const albumEl = document.createElement("div")
      albumEl.classList.add("album-card")
      albumEl.innerHTML = `
        <div class="album-image">
          <img src="${album.cover}" alt="${album.title}" class="img-cover">
          <div class="album-play-button">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M8 5v14l11-7z"/>
            </svg>
          </div>
        </div>
        <div class="album-info">
          <div class="album-title">${album.title}</div>
          <div class="album-artist">${album.artist}</div>
        </div>
      `

      albumEl.addEventListener("click", () => {
        alert(`Album "${album.title}" by ${album.artist} selected. This would show album details.`)
      })

      popularAlbumsContainer.appendChild(albumEl)
    })
  }

  // Load new releases
  function loadNewReleases() {
    newReleasesContainer.innerHTML = ""

    newReleases.forEach((album) => {
      const albumEl = document.createElement("div")
      albumEl.classList.add("album-card")
      albumEl.innerHTML = `
        <div class="album-image">
          <img src="${album.cover}" alt="${album.title}" class="img-cover">
          <div class="album-play-button">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M8 5v14l11-7z"/>
            </svg>
          </div>
        </div>
        <div class="album-info">
          <div class="album-title">${album.title}</div>
          <div class="album-artist">${album.artist}</div>
        </div>
      `

      albumEl.addEventListener("click", () => {
        alert(`Album "${album.title}" by ${album.artist} selected. This would show album details.`)
      })

      newReleasesContainer.appendChild(albumEl)
    })
  }

  // Load trending artists
  function loadTrendingArtists() {
    trendingArtistsContainer.innerHTML = ""

    trendingArtists.forEach((artist) => {
      const artistEl = document.createElement("div")
      artistEl.classList.add("artist-card")
      artistEl.innerHTML = `
        <div class="artist-image">
          <img src="${artist.image}" alt="${artist.name}" class="img-cover">
        </div>
        <div class="artist-name">${artist.name}</div>
      `

      artistEl.addEventListener("click", () => {
        alert(`Artist ${artist.name} selected. This would show artist details.`)
      })

      trendingArtistsContainer.appendChild(artistEl)
    })
  }

  // Search functionality
  musicSearchInput.addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase().trim()

    if (!searchTerm) {
      musicSearchResults.innerHTML = ""
      return
    }

    // Search in tracks
    const filteredTracks = audioTracks.filter(
      (track) => track.title.toLowerCase().includes(searchTerm) || track.artist.toLowerCase().includes(searchTerm),
    )

    // Search in albums
    const filteredAlbums = [...popularAlbums, ...newReleases].filter(
      (album) => album.title.toLowerCase().includes(searchTerm) || album.artist.toLowerCase().includes(searchTerm),
    )

    // Search in artists
    const filteredArtists = trendingArtists.filter((artist) => artist.name.toLowerCase().includes(searchTerm))

    // Display results
    musicSearchResults.innerHTML = ""

    if (filteredTracks.length === 0 && filteredAlbums.length === 0 && filteredArtists.length === 0) {
      musicSearchResults.innerHTML = `<p class="no-results">No results found for "${searchTerm}"</p>`
      return
    }

    // Add tracks to results
    filteredTracks.forEach((track, index) => {
      const trackIndex = audioTracks.findIndex((t) => t.id === track.id)
      const trackEl = document.createElement("div")
      trackEl.classList.add("search-result-item")
      trackEl.innerHTML = `
        <div class="album-card">
          <div class="album-image">
            <img src="${track.cover}" alt="${track.title}" class="img-cover">
            <div class="album-play-button">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                <path d="M8 5v14l11-7z"/>
              </svg>
            </div>
          </div>
          <div class="album-info">
            <div class="album-title">${track.title}</div>
            <div class="album-artist">${track.artist}</div>
          </div>
        </div>
      `

      trackEl.addEventListener("click", () => {
        currentTrackIndex = trackIndex
        loadTrack(currentTrackIndex)
        playTrack()

        // Close search modal
        document.querySelector("[search-modal]").classList.remove("active")
      })

      musicSearchResults.appendChild(trackEl)
    })

    // Add albums to results
    filteredAlbums.forEach((album) => {
      const albumEl = document.createElement("div")
      albumEl.classList.add("search-result-item")
      albumEl.innerHTML = `
        <div class="album-card">
          <div class="album-image">
            <img src="${album.cover}" alt="${album.title}" class="img-cover">
            <div class="album-play-button">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                <path d="M8 5v14l11-7z"/>
              </svg>
            </div>
          </div>
          <div class="album-info">
            <div class="album-title">${album.title}</div>
            <div class="album-artist">${album.artist}</div>
          </div>
        </div>
      `

      albumEl.addEventListener("click", () => {
        alert(`Album "${album.title}" by ${album.artist} selected. This would show album details.`)

        // Close search modal
        document.querySelector("[search-modal]").classList.remove("active")
      })

      musicSearchResults.appendChild(albumEl)
    })
  })

  // Initialize MusicBrainz API integration
  async function fetchFromMusicBrainz(endpoint, params = {}) {
    const baseUrl = "https://musicbrainz.org/ws/2"
    const queryParams = new URLSearchParams({
      fmt: "json",
      ...params,
    })

    try {
      const response = await fetch(`${baseUrl}${endpoint}?${queryParams}`, {
        headers: {
          "User-Agent": "Panyero/1.0 (https://panyero.com)",
        },
      })

      if (!response.ok) {
        throw new Error(`MusicBrainz API error: ${response.status}`)
      }

      return await response.json()
    } catch (error) {
      console.error("Error fetching from MusicBrainz:", error)
      return null
    }
  }

  // Function to get cover art URL from Cover Art Archive
  function getCoverArtUrl(mbid, size = 250) {
    return `https://coverartarchive.org/release/${mbid}/front-${size}`
  }

  // Function to get a fallback cover art URL
  function getFallbackCoverArt(index) {
    const fallbackImages = [
      "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
      "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
      "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
      "https://images.unsplash.com/photo-1487180144351-b8472da7d491?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
      "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
      "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
    ]

    return fallbackImages[index % fallbackImages.length]
  }

  // Fetch MusicBrainz data for trending artists
  async function fetchTrendingArtists() {
    try {
      const data = await fetchFromMusicBrainz("/artist", {
        query: "tag:popular AND type:group",
        limit: 8,
      })

      if (data && data.artists && data.artists.length > 0) {
        trendingArtistsContainer.innerHTML = ""

        data.artists.forEach((artist, index) => {
          const artistEl = document.createElement("div")
          artistEl.classList.add("artist-card")

          // Use fallback image since MusicBrainz doesn't provide artist images directly
          const imageUrl = getFallbackCoverArt(index)

          artistEl.innerHTML = `
            <div class="artist-image">
              <img src="${imageUrl}" alt="${artist.name}" class="img-cover">
            </div>
            <div class="artist-name">${artist.name}</div>
          `

          artistEl.addEventListener("click", () => {
            alert(`Artist ${artist.name} selected. This would show artist details.`)
          })

          trendingArtistsContainer.appendChild(artistEl)
        })
      } else {
        // Fallback to static data if API fails
        loadTrendingArtists()
      }
    } catch (error) {
      console.error("Error fetching trending artists:", error)
      // Fallback to static data
      loadTrendingArtists()
    }
  }

  // Fetch MusicBrainz data for popular albums
  async function fetchPopularAlbums() {
    try {
      const data = await fetchFromMusicBrainz("/release", {
        query: "tag:popular AND status:official",
        limit: 6,
      })

      if (data && data.releases && data.releases.length > 0) {
        popularAlbumsContainer.innerHTML = ""

        data.releases.forEach((release, index) => {
          const albumEl = document.createElement("div")
          albumEl.classList.add("album-card")

          // Try to get cover art from MusicBrainz, fallback to static images
          const imageUrl = release.id
            ? `https://coverartarchive.org/release/${release.id}/front-250`
            : getFallbackCoverArt(index)

          const artistName =
            release["artist-credit"] && release["artist-credit"][0]
              ? release["artist-credit"][0].name
              : "Various Artists"

          albumEl.innerHTML = `
            <div class="album-image">
              <img src="${imageUrl}" alt="${release.title}" class="img-cover" onerror="this.src='${getFallbackCoverArt(index)}'">
              <div class="album-play-button">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M8 5v14l11-7z"/>
                </svg>
              </div>
            </div>
            <div class="album-info">
              <div class="album-title">${release.title}</div>
              <div class="album-artist">${artistName}</div>
            </div>
          `

          albumEl.addEventListener("click", () => {
            alert(`Album "${release.title}" by ${artistName} selected. This would show album details.`)
          })

          popularAlbumsContainer.appendChild(albumEl)
        })
      } else {
        // Fallback to static data if API fails
        loadPopularAlbums()
      }
    } catch (error) {
      console.error("Error fetching popular albums:", error)
      // Fallback to static data
      loadPopularAlbums()
    }
  }

  // Initialize the player
  function initPlayer() {
    // Load initial data
    loadMusicCategories()
    loadFeaturedTracks()
    loadPopularAlbums()
    loadNewReleases()
    loadTrendingArtists()

    // Try to fetch data from MusicBrainz
    fetchTrendingArtists()
    fetchPopularAlbums()

    // Load the first track
    loadTrack(0)

    // Add scroll event to change header background
    window.addEventListener("scroll", () => {
      const header = document.querySelector(".header")
      if (window.scrollY > 50) {
        header.classList.add("scrolled")
      } else {
        header.classList.remove("scrolled")
      }
    })
  }

  // Initialize the player
  initPlayer()
})

// Initialize search
search()

