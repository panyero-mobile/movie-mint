const CACHE_NAME = "moviemint-cache-v1"
const OFFLINE_URL = "/offline.html"
const OFFLINE_IMG = "/assets/images/poster-bg-icon.png"
const OFFLINE_AUDIO = "/assets/audio/offline-audio.mp3"

// Assets to cache immediately on service worker install
const PRECACHE_ASSETS = [
  "/",
  "/index.html",
  "/offline.html",
  "/splash.html",
  "/detail.html",
  "/tv-shows.html",
  "/tv-detail.html",
  "/music.html",
  "/categories.html",
  "/movie-list.html",
  "/assets/css/style.css",
  "/assets/css/music.css",
  "/assets/css/splash.css",
  "/assets/js/global.js",
  "/assets/js/index.js",
  "/assets/js/api.js",
  "/assets/js/movie-card.js",
  "/assets/js/tv-card.js",
  "/assets/js/search.js",
  "/assets/js/sidebar.js",
  "/assets/js/detail.js",
  "/assets/js/tv-detail.js",
  "/assets/js/music.js",
  "/assets/js/download-manager.js",
  "/assets/js/offline-manager.js",
  "/assets/images/poster-bg-icon.png",
  "/assets/images/video-bg-icon.png",
  "/assets/images/logo.svg",
  "/assets/images/icons/icon-192x192.png",
  "/assets/images/icons/icon-512x512.png",
  "/assets/audio/offline-audio.mp3",
  "/manifest.json",
]

// Install event - precache key assets
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => {
        console.log("Opened cache")
        return cache.addAll(PRECACHE_ASSETS)
      })
      .then(() => self.skipWaiting()),
  )
})

// Activate event - clean up old caches
self.addEventListener("activate", (event) => {
  const cacheWhitelist = [CACHE_NAME]
  event.waitUntil(
    caches
      .keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (cacheWhitelist.indexOf(cacheName) === -1) {
              return caches.delete(cacheName)
            }
          }),
        )
      })
      .then(() => self.clients.claim()),
  )
})

// Fetch event - serve from cache or network
self.addEventListener("fetch", (event) => {
  // Skip cross-origin requests
  if (!event.request.url.startsWith(self.location.origin)) {
    return
  }

  // Handle API requests differently (don't cache by default)
  if (
    event.request.url.includes("api.themoviedb.org") ||
    event.request.url.includes("musicbrainz.org") ||
    event.request.url.includes("vidsrc.xyz")
  ) {
    // For API requests, try network first, then fall back to cached response if available
    event.respondWith(fetch(event.request).catch(() => caches.match(event.request)))
    return
  }

  // For media files that might be downloaded for offline use
  if (event.request.url.includes("/downloads/")) {
    event.respondWith(caches.match(event.request))
    return
  }

  // For page navigation requests
  if (event.request.mode === "navigate") {
    event.respondWith(
      fetch(event.request).catch(() => {
        return caches.match(OFFLINE_URL)
      }),
    )
    return
  }

  // For image requests
  if (event.request.destination === "image") {
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        return (
          cachedResponse ||
          fetch(event.request)
            .then((networkResponse) => {
              // Cache successful responses
              if (networkResponse && networkResponse.ok) {
                const responseToCache = networkResponse.clone()
                caches.open(CACHE_NAME).then((cache) => {
                  cache.put(event.request, responseToCache)
                })
              }
              return networkResponse
            })
            .catch(() => {
              // If both cache and network fail, return fallback image
              if (event.request.url.includes("poster") || event.request.url.includes("backdrop")) {
                return caches.match(OFFLINE_IMG)
              }
            })
        )
      }),
    )
    return
  }

  // For audio requests
  if (event.request.destination === "audio") {
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        return (
          cachedResponse ||
          fetch(event.request).catch(() => {
            // If both cache and network fail, return fallback audio
            return caches.match(OFFLINE_AUDIO)
          })
        )
      }),
    )
    return
  }

  // Default strategy: stale-while-revalidate
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      // Return cached response if available
      if (cachedResponse) {
        // Revalidate the cache in the background
        fetch(event.request)
          .then((networkResponse) => {
            if (networkResponse && networkResponse.ok) {
              caches.open(CACHE_NAME).then((cache) => {
                cache.put(event.request, networkResponse.clone())
              })
            }
          })
          .catch((error) => console.log("Network fetch failed:", error))

        return cachedResponse
      }

      // Otherwise try to fetch from network
      return fetch(event.request)
        .then((networkResponse) => {
          if (!networkResponse || !networkResponse.ok) {
            return networkResponse
          }

          // Cache successful responses
          const responseToCache = networkResponse.clone()
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache)
          })

          return networkResponse
        })
        .catch((error) => {
          console.log("Fetch failed:", error)
          // If both cache and network fail, return offline page for navigation
          if (event.request.mode === "navigate") {
            return caches.match(OFFLINE_URL)
          }
          return null
        })
    }),
  )
})

// Background sync for pending downloads
self.addEventListener("sync", (event) => {
  if (event.tag === "sync-pending-downloads") {
    event.waitUntil(syncPendingDownloads())
  }
})

// Background fetch for downloading content
self.addEventListener("backgroundfetchsuccess", (event) => {
  const bgFetch = event.registration

  event.waitUntil(
    (async () => {
      try {
        // Get all the records
        const records = await bgFetch.matchAll()

        // Process all the records
        const promises = records.map(async (record) => {
          const response = await record.responseReady
          const cache = await caches.open("downloads")

          // Extract the ID from the URL
          const url = new URL(record.request.url)
          const id = url.searchParams.get("id")

          // Store in cache with a predictable URL
          await cache.put(`/downloads/${id}`, response)
        })

        await Promise.all(promises)

        // Notify the client that the download is complete
        const clients = await self.clients.matchAll()
        clients.forEach((client) => {
          client.postMessage({
            type: "download-complete",
            id: bgFetch.id,
          })
        })
      } catch (err) {
        console.error("Background fetch failed:", err)
      }
    })(),
  )
})

self.addEventListener("backgroundfetchfail", (event) => {
  console.error("Background fetch failed:", event)

  event.waitUntil(
    (async () => {
      // Notify clients of failure
      const clients = await self.clients.matchAll()
      clients.forEach((client) => {
        client.postMessage({
          type: "download-failed",
          id: event.registration.id,
        })
      })
    })(),
  )
})

self.addEventListener("backgroundfetchabort", (event) => {
  console.log("Background fetch aborted:", event)
})

// Push notifications
self.addEventListener("push", (event) => {
  const data = event.data.json()

  const options = {
    body: data.body,
    icon: "/assets/images/icons/icon-192x192.png",
    badge: "/assets/images/icons/badge-72x72.png",
    vibrate: [100, 50, 100],
    data: {
      url: data.url,
    },
  }

  event.waitUntil(self.registration.showNotification(data.title, options))
})

self.addEventListener("notificationclick", (event) => {
  event.notification.close()

  if (event.notification.data && event.notification.data.url) {
    event.waitUntil(clients.openWindow(event.notification.data.url))
  }
})

// Helper function to sync pending downloads
async function syncPendingDownloads() {
  try {
    const db = await openDownloadsDB()
    const pendingDownloads = await db.getAll("pending")

    const downloadPromises = pendingDownloads.map(async (download) => {
      try {
        // Check if background fetch is supported
        if ("BackgroundFetchManager" in self.registration) {
          const bgFetch = await self.registration.backgroundFetch.fetch(`download-${download.id}`, [download.url], {
            title: `Downloading ${download.title}`,
            icons: [
              {
                sizes: "192x192",
                src: "/assets/images/icons/icon-192x192.png",
                type: "image/png",
              },
            ],
            downloadTotal: download.size || 50 * 1024 * 1024, // Default to 50MB if size unknown
          })

          // Update status in the database
          await db.put("pending", {
            ...download,
            status: "downloading",
            bgFetchId: bgFetch.id,
          })
        } else {
          // Fallback for browsers without background fetch
          const response = await fetch(download.url)
          const blob = await response.blob()

          // Store in cache
          const cache = await caches.open("downloads")
          await cache.put(`/downloads/${download.id}`, new Response(blob))

          // Move from pending to completed
          await db.delete("pending", download.id)
          await db.add("completed", {
            ...download,
            status: "completed",
            downloadedAt: Date.now(),
          })

          // Notify clients
          const clients = await self.clients.matchAll()
          clients.forEach((client) => {
            client.postMessage({
              type: "download-complete",
              id: download.id,
            })
          })
        }
      } catch (error) {
        console.error(`Failed to download ${download.title}:`, error)

        // Update status to failed
        await db.put("pending", {
          ...download,
          status: "failed",
          error: error.message,
        })

        // Notify clients
        const clients = await self.clients.matchAll()
        clients.forEach((client) => {
          client.postMessage({
            type: "download-failed",
            id: download.id,
            error: error.message,
          })
        })
      }
    })

    await Promise.all(downloadPromises)
  } catch (error) {
    console.error("Failed to sync pending downloads:", error)
  }
}

// Helper function to open the downloads database
function openDownloadsDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("downloads-db", 1)

    request.onerror = (event) => {
      reject("Failed to open downloads database")
    }

    request.onsuccess = (event) => {
      const db = event.target.result

      resolve({
        get: (store, key) => {
          return new Promise((resolve, reject) => {
            const transaction = db.transaction(store, "readonly")
            const objectStore = transaction.objectStore(store)
            const request = objectStore.get(key)

            request.onsuccess = (event) => {
              resolve(event.target.result)
            }

            request.onerror = (event) => {
              reject("Failed to get item from database")
            }
          })
        },
        getAll: (store) => {
          return new Promise((resolve, reject) => {
            const transaction = db.transaction(store, "readonly")
            const objectStore = transaction.objectStore(store)
            const request = objectStore.getAll()

            request.onsuccess = (event) => {
              resolve(event.target.result)
            }

            request.onerror = (event) => {
              reject("Failed to get items from database")
            }
          })
        },
        add: (store, item) => {
          return new Promise((resolve, reject) => {
            const transaction = db.transaction(store, "readwrite")
            const objectStore = transaction.objectStore(store)
            const request = objectStore.add(item)

            request.onsuccess = (event) => {
              resolve(event.target.result)
            }

            request.onerror = (event) => {
              reject("Failed to add item to database")
            }
          })
        },
        put: (store, item) => {
          return new Promise((resolve, reject) => {
            const transaction = db.transaction(store, "readwrite")
            const objectStore = transaction.objectStore(store)
            const request = objectStore.put(item)

            request.onsuccess = (event) => {
              resolve(event.target.result)
            }

            request.onerror = (event) => {
              reject("Failed to update item in database")
            }
          })
        },
        delete: (store, key) => {
          return new Promise((resolve, reject) => {
            const transaction = db.transaction(store, "readwrite")
            const objectStore = transaction.objectStore(store)
            const request = objectStore.delete(key)

            request.onsuccess = (event) => {
              resolve()
            }

            request.onerror = (event) => {
              reject("Failed to delete item from database")
            }
          })
        },
      })
    }

    request.onupgradeneeded = (event) => {
      const db = event.target.result

      // Create object stores
      if (!db.objectStoreNames.contains("pending")) {
        const pendingStore = db.createObjectStore("pending", { keyPath: "id" })
        pendingStore.createIndex("status", "status", { unique: false })
      }

      if (!db.objectStoreNames.contains("completed")) {
        const completedStore = db.createObjectStore("completed", { keyPath: "id" })
        completedStore.createIndex("downloadedAt", "downloadedAt", { unique: false })
      }
    }
  })
}

